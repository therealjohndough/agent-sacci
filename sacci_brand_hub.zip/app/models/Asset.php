<?php

namespace App\Models;

class Asset extends BaseModel
{
    protected static string $table = 'assets';
}