<?php

namespace App\Models;

class Organization extends BaseModel
{
    protected static string $table = 'organizations';
}