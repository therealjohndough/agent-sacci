<?php

namespace App\Models;

class Setting extends BaseModel
{
    protected static string $table = 'settings';
}