<?php

namespace App\Models;

class TicketComment extends BaseModel
{
    protected static string $table = 'ticket_comments';
}