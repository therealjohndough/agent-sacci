<?php

namespace App\Models;

class ContentBlock extends BaseModel
{
    protected static string $table = 'content_blocks';
}