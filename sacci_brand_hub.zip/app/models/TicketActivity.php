<?php

namespace App\Models;

class TicketActivity extends BaseModel
{
    protected static string $table = 'ticket_activities';
}