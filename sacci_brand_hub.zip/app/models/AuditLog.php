<?php

namespace App\Models;

class AuditLog extends BaseModel
{
    protected static string $table = 'audit_logs';
}